﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ADMIN_DivorceViewProfile : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // if (!IsPostBack)
        //{
        //            string sql = "select * from divorcescommon";
        //            DataSet ds = new DataSet();
        //            ds = DAL.SqlHelper.ExecuteDataset(clsConnection.Connection, CommandType.Text, sql);

        //            txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             .Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //            txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //             txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();
        //            txt_dob.Text = ds.Tables[0].Rows[0]["dob"].ToString();

        //    }
        //}
    }
}