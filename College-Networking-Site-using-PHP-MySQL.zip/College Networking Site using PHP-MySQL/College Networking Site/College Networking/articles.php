<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
<head>
<title>Social Networking Template</title>
<meta name="Keywords" content="">
<meta name="Description" content="">
<link href="style.css" rel="stylesheet" type="text/css">

</head>

<body>

<center>
<div class=container>

<!-- head -->
<?php include("head.php"); ?>
<!-- navigation menu -->
<div class=nav>
	<?php include("menu.php"); ?> 
</div>

<div style="padding: 10px; text-align: left;">
<!-- body  content -->
<table cellpadding=10 width=100%>
<tr>
	<td height=400 valign=top>
		<?php include("Qart.php"); ?>
	</td>
</tr>
</table>

</div>

<!--  
COPYRIGHT
Do not change or remove the reference to DatingSiteBuilder if you use the free version
-->
<div class=foot>Copyright &copy; 2011. All Rights Reserved. </div>
<center>

</body>
</html>