<?php
$author = "kerphi";
$website = "http://www.dhavalcollege.com";
?>